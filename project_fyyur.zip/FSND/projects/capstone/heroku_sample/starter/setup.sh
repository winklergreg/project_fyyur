#!/bin/bash
export DATABASE_URL="postgresql://postgres@localhost:5432/postgres"
export EXCITED="true"
echo "setup.sh script executed successfully!"