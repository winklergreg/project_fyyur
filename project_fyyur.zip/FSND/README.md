## Full Stack Web Developer Nanodegree (nd0044 v2)
This is the public repository for Udacity's Full-Stack Nanodegree program. Here, you can find starter-code the following projects:

* *01_fyyur/starter_code* - This is the project from C1. SQL and Data Modeling for the Web
* *02_trivia_api/starter* - This is the project from C2. API Development and Documentation
* *03_coffee_shop_full_stack/starter_code* - This is the project from C3. Identity and Access Management
* *capstone* - This is the final project of this Nanodegree.

Feel free to suggest edits in the current repo by raising a PR.


